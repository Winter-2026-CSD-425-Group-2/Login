const mysql = require("mysql2/promise");

exports.handler = async (event) => {

    try {
        const body = JSON.parse(event.body || "{}");
        const username = body.username;

        if (!username) {
            return {
                statusCode: 400,
                headers: { "Access-Control-Allow-Origin": "*" },
                body: JSON.stringify({ message: "Username required" })
            };
        }

        const connection = await mysql.createConnection({
            host: process.env.DB_HOST,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            database: process.env.DB_NAME
        });

        await connection.execute(
            "INSERT INTO users (username) VALUES (?)",
            [username]
        );

        await connection.end();

        return {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "*" },
            body: JSON.stringify({ message: "User added successfully" })
        };

    } catch (error) {

        console.log("ERROR:", error);

        return {
            statusCode: 500,
            headers: { "Access-Control-Allow-Origin": "*" },
            body: JSON.stringify({ message: error.message })
        };
    }
};
